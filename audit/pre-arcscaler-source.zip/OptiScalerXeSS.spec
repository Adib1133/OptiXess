# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [('C:/Users/MG/AppData/Local/Python/pythoncore-3.14-64/Lib/site-packages/customtkinter', 'customtkinter'), ('C:/Users/MG/Desktop/New folder/GUI astra last/GUI astra/assets/icon.ico', 'assets'), ('C:/Users/MG/Desktop/New folder/GUI astra last/GUI astra/assets/versions/v0.9.4', 'assets/versions/v0.9.4')]
binaries = []
hiddenimports = ['psutil', 'PIL', 'tkinter']
tmp_ret = collect_all('py7zr')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['C:/Users/MG/Desktop/New folder/GUI astra last/GUI astra/main.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='OptiScalerXeSS',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['C:/Users/MG/Desktop/New folder/GUI astra last/GUI astra/assets/icon.ico'],
)
